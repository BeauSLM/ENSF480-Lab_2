/*
 * File Name: dictionaryList.cpp
 * Assignment: Lab 2 Exercise A
 * Completed By: Beau McCartney, Quentin Jennings
 * Submission Date: September 30th, 2021
 */


#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

//testing function
class GraphicsWorld {
    public:
        static void run();
        // PROMISES: a main function testing our classes
};
#endif

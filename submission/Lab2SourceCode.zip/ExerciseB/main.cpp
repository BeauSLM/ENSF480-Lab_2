/*
 * File Name: dictionaryList.cpp
 * Assignment: Lab 2 Exercise A
 * Completed By: Beau McCartney, Quentin Jennings
 * Submission Date: September 30th, 2021
 */
#include "graphicsworld.h"

int main (int argc, char *argv[])
{
    GraphicsWorld::run();
    return 0;
}
